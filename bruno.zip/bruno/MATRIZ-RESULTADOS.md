# Matriz de resultados Bruno — Integrante 1

Completar **Resultado observado** y **Veredicto** solo tras ejecución auténtica en Bruno Desktop.

SHA código base (colección reorganizada sobre): `b078a0c5c776b2730b561f9554c0b143261089d3`  
SHA probado (tras commit de esta colección, si aplica): _pendiente_  
Probador: _pendiente_  
Fecha: _pendiente_

Convención de captura (crear el PNG únicamente si existe evidencia): `{ID}_{Tema}_{HTTP}.png`

| ID | Módulo | Objetivo | Precondiciones | Método y ruta | Datos de entrada | Resultado esperado | Resultado observado | Coincidencia | Veredicto | Fecha | Probador | SHA probado | Captura | Observaciones |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PRE-00 | app | Salud | Backend 8080 | GET `/api/health` | — | 200 service ok | | | No ejecutada | | | | `PRE-00_Health_200.png` | |
| M1-POST-01 | M1 | Auth válida | local.secrets, seed | POST `/api/v1/personal/autenticar` | correo docente + password entorno | 200 tokenType Bearer, authPrototype TD-M1-AUTH-PROVISIONAL | | | No ejecutada | | | | `M1-POST-01_AuthCorrecta_200.png` | Ocultar token |
| M1-POST-02 | M1 | Clave incorrecta | Docente existe | POST autenticar | password incorrecto fijo | 401 AUTH_FAILED | | | No ejecutada | | | | `M1-POST-02_ClaveIncorrecta_401.png` | No pisa accessToken |
| M1-POST-03 | M1 | Usuario inexistente | — | POST autenticar | unknownEmail | 401 AUTH_FAILED | | | No ejecutada | | | | `M1-POST-03_UsuarioInexistente_401.png` | |
| M1-NEG-01 | M1 | Usuario inactivo | Seed inactive | POST autenticar | inactiveEmail | 401 AUTH_FAILED | | | No ejecutada | | | | `M1-NEG-01_UsuarioInactivo_401.png` | |
| M1-POST-07 | M1 | Validación | — | POST autenticar | correo inválido, password vacío | 400 VALIDATION_ERROR | | | No ejecutada | | | | `M1-POST-07_DatosInvalidos_400.png` | |
| M1-PERF-01 | M1 | /me | 01-01 | GET `/api/v1/personal/me` | Bearer accessToken | 200 correo docente | | | No ejecutada | | | | `M1-PERF-01_Me_200.png` | |
| M1-GET-04 | M1 | /me sin token | — | GET `/me` | sin Authorization | 401 UNAUTHENTICATED | | | No ejecutada | | | | `M1-GET-04_MeSinToken_401.png` | |
| M1-GET-06 | M1 | CREAR_CASO | 01-01 | GET `/autorizacion/crear-caso` | Bearer docente | 200 allowed true | | | No ejecutada | | | | `M1-GET-06_CrearCaso_200.png` | |
| M1-GET-05 | M1 | Sin CREAR_CASO | 02-04-prep | GET crear-caso | Bearer noPermAccessToken | 403 FORBIDDEN | | | No ejecutada | | | | `M1-GET-05_SinCrearCaso_403.png` | |
| M1-NEG-02 | M1 | Token inválido | — | GET `/me` | Bearer falso | 401 UNAUTHENTICATED | | | No ejecutada | | | | `M1-NEG-02_TokenInvalido_401.png` | |
| M1-POST-08 | M1 | DD-02 off | Flag false | POST `/acceso-estudiante/validar` | challengeId + codigo 8 dígitos | 501 ESTUDIANTE_ACCESS_PENDING_CONTRACT | | | No ejecutada | | | | `M1-POST-08_DD02_501.png` | No activar DD-02 |
| M1-NEG-03 | M1 | Validar inválido | — | POST `/validar` | correo + codigo no numérico | 400 VALIDATION_ERROR | | | No ejecutada | | | | `M1-NEG-03_ValidarInvalido_400.png` | |
| M7-PREP-01 | M1 | Auth M7 | Seed GESTIONAR_SESION | POST autenticar | docente | 200 | | | No ejecutada | | | | `M7-PREP-01_AuthDocente_200.png` | |
| M7-PREP-02 | M4 | Crear sesión | 04-01, caso seed | POST `/api/m4/sesiones` | casoIdBruno | 201 + id | | | No ejecutada | | | | `M7-PREP-02_CrearSesion_201.png` | |
| M7-via-M4-01 | M4/M7 | Convocar | sesionId, estudiante seed | POST `.../convocatorias` | estudianteIdBruno | 201; no SMTP | | | No ejecutada | | | | `M7-via-M4-01_Convocatoria_201.png` | Pendiente ≠ Enviado |
| M7-VER-01 | M4 | Listar | 04-03 | GET convocatorias | sesionId | 200 | | | No ejecutada | | | | `M7-VER-01_Listar_200.png` | |
| M7-via-M4-02 | M4 | Sin permiso | noPerm token | POST `/m4/sesiones` | caso seed | 403 M4-SIN-PERMISO | | | No ejecutada | | | | `M7-via-M4-02_SinPermiso_403.png` | |
| M7-via-M4-03 | M4 | Sin token | sesionId | POST convocatorias | estudiante | 401 | | | No ejecutada | | | | `M7-via-M4-03_SinToken_401.png` | |
| M1-POST-09 | M1 | Logout | Token docente | POST `/cerrar-sesion` | Bearer | 204 | | | No ejecutada | | | | `M1-POST-09_CerrarSesion_204.png` | Tras carpeta 04 |
| M1-VER-02 | M1 | Token revocado | 05-01 | GET `/me` | mismo Bearer | 401 UNAUTHENTICATED | | | No ejecutada | | | | `M1-VER-02_TokenRevocado_401.png` | |
